"""
This package defines the main `telethon._client.telegramclient.TelegramClient` instance
which delegates the work to free-standing functions defined in the rest of files.
"""
